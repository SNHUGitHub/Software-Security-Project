package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Add additional libraries
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.NoSuchAlgorithmException;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";

@RestController
class ServerController {
	public String calculateHash(String data) throws NoSuchAlgorithmException {
	    	
	    	// Create object of MessageDigest class and initialize it with algorithm cipher SHA-256
	    	MessageDigest md = MessageDigest.getInstance("SHA-256");
	    	
	    	// Use digest() method of MessageDigest class to generate hash value of byte type from data variable
	    	byte[] hashValue = md.digest(data.getBytes(StandardCharsets.UTF_8));
	    	
	    	// Return hex of hash value
	    	return bytesToHex(hashValue);
	}
	
	// Function to convert hash value to hex
	public String bytesToHex(byte[] hashValue) {
		
		BigInteger hexValue = new BigInteger(1, hashValue);
		
    	StringBuilder checksumValue = new StringBuilder(hexValue.toString(16));
    	
    	if (checksumValue.length() < 32) {
    		
    		checksumValue.insert(0, '0');
    	}
 
    	return checksumValue.toString();
	}
	
	// Create RESTFul route using @RequestMapping method to return required information
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException {
		
		// Define and initialize local variables
		String data = "Hello World Check Sum! Created by Quinnie Ho.";
		
		String checksumValue = calculateHash(data);
    	
		// Return required information to web browser
    	return "Data: " + data + "<p>Name of Cipher Algorithm Used: CheckSum " + "<p>Value: " + checksumValue;
    }
}
